﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvc
{
    class Program
    {
        static void Main(string[] args)
        {
            mvc mvc = new mvc(args);
        }
    }
}
