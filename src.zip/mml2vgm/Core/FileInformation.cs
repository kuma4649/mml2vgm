﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public static class FileInformation
    {
        public static long totalCounter = 0;
        public static long loopCounter = -1;
        public static enmFormat format = enmFormat.VGM;
    }
}
