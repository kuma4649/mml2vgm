﻿namespace mml2vgmIDE
{
    partial class ucSettingInstruments
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbYM2151P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2151P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2151P_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2151P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbYM2151P_EmuX68Sound = new System.Windows.Forms.RadioButton();
            this.rbYM2151P_EmuMame = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbYM2151S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2151S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2151S_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2151S_EmuX68Sound = new System.Windows.Forms.RadioButton();
            this.rbYM2151S_EmuMame = new System.Windows.Forms.RadioButton();
            this.rbYM2151S_Emu = new System.Windows.Forms.RadioButton();
            this.cmbYM2203P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2203P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2203P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbYM2203P_Silent = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmbYM2203S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2203S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2203S_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2203S_Emu = new System.Windows.Forms.RadioButton();
            this.cmbYM2608P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2608P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2608P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rbYM2608P_Silent = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cmbYM2608S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2608S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2608S_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2608S_Emu = new System.Windows.Forms.RadioButton();
            this.cmbYM2610BP_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2610BP_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2610BP_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSPPCMP_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2610BP_Silent = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbYM2610BS_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2610BS_SCCI = new System.Windows.Forms.RadioButton();
            this.cmbSPPCMS_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2610BS_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2610BS_Emu = new System.Windows.Forms.RadioButton();
            this.cbEmulationPCMOnly = new System.Windows.Forms.CheckBox();
            this.cbTwice = new System.Windows.Forms.CheckBox();
            this.cbSendWait = new System.Windows.Forms.CheckBox();
            this.cmbYM2612P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2612P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2612P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rbYM2612P_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2612P_EmuNuked = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rbYM2612S_Silent = new System.Windows.Forms.RadioButton();
            this.cmbYM2612S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2612S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2612S_EmuNuked = new System.Windows.Forms.RadioButton();
            this.rbYM2612S_Emu = new System.Windows.Forms.RadioButton();
            this.cmbSN76489P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbSN76489P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbSN76489P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.rbSN76489P_Silent = new System.Windows.Forms.RadioButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.cmbSN76489S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbSN76489S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbSN76489S_Silent = new System.Windows.Forms.RadioButton();
            this.rbSN76489S_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cmbC140S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbC140S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbC140S_Silent = new System.Windows.Forms.RadioButton();
            this.rbC140S_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.cmbC140P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbC140P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbC140P_Silent = new System.Windows.Forms.RadioButton();
            this.rbC140P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.cmbSEGAPCMS_SCCI = new System.Windows.Forms.ComboBox();
            this.rbSEGAPCMS_SCCI = new System.Windows.Forms.RadioButton();
            this.rbSEGAPCMS_Silent = new System.Windows.Forms.RadioButton();
            this.rbSEGAPCMS_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.cmbSEGAPCMP_SCCI = new System.Windows.Forms.ComboBox();
            this.rbSEGAPCMP_SCCI = new System.Windows.Forms.RadioButton();
            this.rbSEGAPCMP_Silent = new System.Windows.Forms.RadioButton();
            this.rbSEGAPCMP_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.cbEmulationOPNBADPCMOnly = new System.Windows.Forms.CheckBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.cbEmulationOPNAADPCMOnly = new System.Windows.Forms.CheckBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.cmbAY8910S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbAY8910S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbAY8910S_Silent = new System.Windows.Forms.RadioButton();
            this.rbAY8910S_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.cmbAY8910P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbAY8910P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbAY8910P_Silent = new System.Windows.Forms.RadioButton();
            this.rbAY8910P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.cmbYM2413P_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2413P_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2413P_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2413P_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.cmbYM2413S_SCCI = new System.Windows.Forms.ComboBox();
            this.rbYM2413S_SCCI = new System.Windows.Forms.RadioButton();
            this.rbYM2413S_Silent = new System.Windows.Forms.RadioButton();
            this.rbYM2413S_Emu = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbYM2151P_SCCI
            // 
            this.cmbYM2151P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2151P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2151P_SCCI.FormattingEnabled = true;
            this.cmbYM2151P_SCCI.Location = new System.Drawing.Point(190, 34);
            this.cmbYM2151P_SCCI.Name = "cmbYM2151P_SCCI";
            this.cmbYM2151P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2151P_SCCI.TabIndex = 2;
            // 
            // rbYM2151P_SCCI
            // 
            this.rbYM2151P_SCCI.AutoSize = true;
            this.rbYM2151P_SCCI.Location = new System.Drawing.Point(138, 35);
            this.rbYM2151P_SCCI.Name = "rbYM2151P_SCCI";
            this.rbYM2151P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2151P_SCCI.TabIndex = 1;
            this.rbYM2151P_SCCI.Text = "Real";
            this.rbYM2151P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2151P_Silent
            // 
            this.rbYM2151P_Silent.AutoSize = true;
            this.rbYM2151P_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2151P_Silent.Name = "rbYM2151P_Silent";
            this.rbYM2151P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2151P_Silent.TabIndex = 0;
            this.rbYM2151P_Silent.Text = "Silent";
            this.rbYM2151P_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2151P_Emu
            // 
            this.rbYM2151P_Emu.AutoSize = true;
            this.rbYM2151P_Emu.Checked = true;
            this.rbYM2151P_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2151P_Emu.Name = "rbYM2151P_Emu";
            this.rbYM2151P_Emu.Size = new System.Drawing.Size(84, 16);
            this.rbYM2151P_Emu.TabIndex = 0;
            this.rbYM2151P_Emu.TabStop = true;
            this.rbYM2151P_Emu.Text = "Emu(fmgen)";
            this.rbYM2151P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.cmbYM2151P_SCCI);
            this.groupBox1.Controls.Add(this.rbYM2151P_SCCI);
            this.groupBox1.Controls.Add(this.rbYM2151P_Silent);
            this.groupBox1.Controls.Add(this.rbYM2151P_EmuX68Sound);
            this.groupBox1.Controls.Add(this.rbYM2151P_EmuMame);
            this.groupBox1.Controls.Add(this.rbYM2151P_Emu);
            this.groupBox1.Location = new System.Drawing.Point(3, 367);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(411, 60);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "YM2151(Primary)";
            // 
            // rbYM2151P_EmuX68Sound
            // 
            this.rbYM2151P_EmuX68Sound.AutoSize = true;
            this.rbYM2151P_EmuX68Sound.Location = new System.Drawing.Point(269, 13);
            this.rbYM2151P_EmuX68Sound.Name = "rbYM2151P_EmuX68Sound";
            this.rbYM2151P_EmuX68Sound.Size = new System.Drawing.Size(103, 16);
            this.rbYM2151P_EmuX68Sound.TabIndex = 0;
            this.rbYM2151P_EmuX68Sound.Text = "Emu(X68Sound)";
            this.rbYM2151P_EmuX68Sound.UseVisualStyleBackColor = true;
            // 
            // rbYM2151P_EmuMame
            // 
            this.rbYM2151P_EmuMame.AutoSize = true;
            this.rbYM2151P_EmuMame.Location = new System.Drawing.Point(165, 13);
            this.rbYM2151P_EmuMame.Name = "rbYM2151P_EmuMame";
            this.rbYM2151P_EmuMame.Size = new System.Drawing.Size(83, 16);
            this.rbYM2151P_EmuMame.TabIndex = 0;
            this.rbYM2151P_EmuMame.Text = "Emu(mame)";
            this.rbYM2151P_EmuMame.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.cmbYM2151S_SCCI);
            this.groupBox2.Controls.Add(this.rbYM2151S_SCCI);
            this.groupBox2.Controls.Add(this.rbYM2151S_Silent);
            this.groupBox2.Controls.Add(this.rbYM2151S_EmuX68Sound);
            this.groupBox2.Controls.Add(this.rbYM2151S_EmuMame);
            this.groupBox2.Controls.Add(this.rbYM2151S_Emu);
            this.groupBox2.Location = new System.Drawing.Point(3, 433);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(411, 60);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "YM2151(Secondary)";
            // 
            // cmbYM2151S_SCCI
            // 
            this.cmbYM2151S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2151S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2151S_SCCI.FormattingEnabled = true;
            this.cmbYM2151S_SCCI.Location = new System.Drawing.Point(190, 34);
            this.cmbYM2151S_SCCI.Name = "cmbYM2151S_SCCI";
            this.cmbYM2151S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2151S_SCCI.TabIndex = 2;
            // 
            // rbYM2151S_SCCI
            // 
            this.rbYM2151S_SCCI.AutoSize = true;
            this.rbYM2151S_SCCI.Location = new System.Drawing.Point(138, 35);
            this.rbYM2151S_SCCI.Name = "rbYM2151S_SCCI";
            this.rbYM2151S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2151S_SCCI.TabIndex = 1;
            this.rbYM2151S_SCCI.Text = "Real";
            this.rbYM2151S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2151S_Silent
            // 
            this.rbYM2151S_Silent.AutoSize = true;
            this.rbYM2151S_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2151S_Silent.Name = "rbYM2151S_Silent";
            this.rbYM2151S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2151S_Silent.TabIndex = 0;
            this.rbYM2151S_Silent.Text = "Silent";
            this.rbYM2151S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2151S_EmuX68Sound
            // 
            this.rbYM2151S_EmuX68Sound.AutoSize = true;
            this.rbYM2151S_EmuX68Sound.Location = new System.Drawing.Point(269, 13);
            this.rbYM2151S_EmuX68Sound.Name = "rbYM2151S_EmuX68Sound";
            this.rbYM2151S_EmuX68Sound.Size = new System.Drawing.Size(103, 16);
            this.rbYM2151S_EmuX68Sound.TabIndex = 0;
            this.rbYM2151S_EmuX68Sound.Text = "Emu(X68Sound)";
            this.rbYM2151S_EmuX68Sound.UseVisualStyleBackColor = true;
            // 
            // rbYM2151S_EmuMame
            // 
            this.rbYM2151S_EmuMame.AutoSize = true;
            this.rbYM2151S_EmuMame.Location = new System.Drawing.Point(165, 13);
            this.rbYM2151S_EmuMame.Name = "rbYM2151S_EmuMame";
            this.rbYM2151S_EmuMame.Size = new System.Drawing.Size(83, 16);
            this.rbYM2151S_EmuMame.TabIndex = 0;
            this.rbYM2151S_EmuMame.Text = "Emu(mame)";
            this.rbYM2151S_EmuMame.UseVisualStyleBackColor = true;
            // 
            // rbYM2151S_Emu
            // 
            this.rbYM2151S_Emu.AutoSize = true;
            this.rbYM2151S_Emu.Checked = true;
            this.rbYM2151S_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2151S_Emu.Name = "rbYM2151S_Emu";
            this.rbYM2151S_Emu.Size = new System.Drawing.Size(84, 16);
            this.rbYM2151S_Emu.TabIndex = 0;
            this.rbYM2151S_Emu.TabStop = true;
            this.rbYM2151S_Emu.Text = "Emu(fmgen)";
            this.rbYM2151S_Emu.UseVisualStyleBackColor = true;
            // 
            // cmbYM2203P_SCCI
            // 
            this.cmbYM2203P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2203P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2203P_SCCI.FormattingEnabled = true;
            this.cmbYM2203P_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2203P_SCCI.Name = "cmbYM2203P_SCCI";
            this.cmbYM2203P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2203P_SCCI.TabIndex = 2;
            // 
            // rbYM2203P_SCCI
            // 
            this.rbYM2203P_SCCI.AutoSize = true;
            this.rbYM2203P_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2203P_SCCI.Name = "rbYM2203P_SCCI";
            this.rbYM2203P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2203P_SCCI.TabIndex = 1;
            this.rbYM2203P_SCCI.Text = "Real";
            this.rbYM2203P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2203P_Emu
            // 
            this.rbYM2203P_Emu.AutoSize = true;
            this.rbYM2203P_Emu.Checked = true;
            this.rbYM2203P_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2203P_Emu.Name = "rbYM2203P_Emu";
            this.rbYM2203P_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2203P_Emu.TabIndex = 0;
            this.rbYM2203P_Emu.TabStop = true;
            this.rbYM2203P_Emu.Text = "Emu";
            this.rbYM2203P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.cmbYM2203P_SCCI);
            this.groupBox3.Controls.Add(this.rbYM2203P_SCCI);
            this.groupBox3.Controls.Add(this.rbYM2203P_Silent);
            this.groupBox3.Controls.Add(this.rbYM2203P_Emu);
            this.groupBox3.Location = new System.Drawing.Point(3, 499);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(411, 38);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "YM2203(Primary)";
            // 
            // rbYM2203P_Silent
            // 
            this.rbYM2203P_Silent.AutoSize = true;
            this.rbYM2203P_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2203P_Silent.Name = "rbYM2203P_Silent";
            this.rbYM2203P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2203P_Silent.TabIndex = 0;
            this.rbYM2203P_Silent.Text = "Silent";
            this.rbYM2203P_Silent.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.cmbYM2203S_SCCI);
            this.groupBox4.Controls.Add(this.rbYM2203S_SCCI);
            this.groupBox4.Controls.Add(this.rbYM2203S_Silent);
            this.groupBox4.Controls.Add(this.rbYM2203S_Emu);
            this.groupBox4.Location = new System.Drawing.Point(3, 543);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(411, 38);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "YM2203(Secondary)";
            // 
            // cmbYM2203S_SCCI
            // 
            this.cmbYM2203S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2203S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2203S_SCCI.FormattingEnabled = true;
            this.cmbYM2203S_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2203S_SCCI.Name = "cmbYM2203S_SCCI";
            this.cmbYM2203S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2203S_SCCI.TabIndex = 2;
            // 
            // rbYM2203S_SCCI
            // 
            this.rbYM2203S_SCCI.AutoSize = true;
            this.rbYM2203S_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2203S_SCCI.Name = "rbYM2203S_SCCI";
            this.rbYM2203S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2203S_SCCI.TabIndex = 1;
            this.rbYM2203S_SCCI.Text = "Real";
            this.rbYM2203S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2203S_Silent
            // 
            this.rbYM2203S_Silent.AutoSize = true;
            this.rbYM2203S_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2203S_Silent.Name = "rbYM2203S_Silent";
            this.rbYM2203S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2203S_Silent.TabIndex = 0;
            this.rbYM2203S_Silent.Text = "Silent";
            this.rbYM2203S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2203S_Emu
            // 
            this.rbYM2203S_Emu.AutoSize = true;
            this.rbYM2203S_Emu.Checked = true;
            this.rbYM2203S_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2203S_Emu.Name = "rbYM2203S_Emu";
            this.rbYM2203S_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2203S_Emu.TabIndex = 0;
            this.rbYM2203S_Emu.TabStop = true;
            this.rbYM2203S_Emu.Text = "Emu";
            this.rbYM2203S_Emu.UseVisualStyleBackColor = true;
            // 
            // cmbYM2608P_SCCI
            // 
            this.cmbYM2608P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2608P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2608P_SCCI.FormattingEnabled = true;
            this.cmbYM2608P_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2608P_SCCI.Name = "cmbYM2608P_SCCI";
            this.cmbYM2608P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2608P_SCCI.TabIndex = 2;
            // 
            // rbYM2608P_SCCI
            // 
            this.rbYM2608P_SCCI.AutoSize = true;
            this.rbYM2608P_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2608P_SCCI.Name = "rbYM2608P_SCCI";
            this.rbYM2608P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2608P_SCCI.TabIndex = 1;
            this.rbYM2608P_SCCI.Text = "Real";
            this.rbYM2608P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2608P_Emu
            // 
            this.rbYM2608P_Emu.AutoSize = true;
            this.rbYM2608P_Emu.Checked = true;
            this.rbYM2608P_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2608P_Emu.Name = "rbYM2608P_Emu";
            this.rbYM2608P_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2608P_Emu.TabIndex = 0;
            this.rbYM2608P_Emu.TabStop = true;
            this.rbYM2608P_Emu.Text = "Emu";
            this.rbYM2608P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.cmbYM2608P_SCCI);
            this.groupBox5.Controls.Add(this.rbYM2608P_SCCI);
            this.groupBox5.Controls.Add(this.rbYM2608P_Silent);
            this.groupBox5.Controls.Add(this.rbYM2608P_Emu);
            this.groupBox5.Location = new System.Drawing.Point(3, 675);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(411, 38);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "YM2608(Primary)";
            // 
            // rbYM2608P_Silent
            // 
            this.rbYM2608P_Silent.AutoSize = true;
            this.rbYM2608P_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2608P_Silent.Name = "rbYM2608P_Silent";
            this.rbYM2608P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2608P_Silent.TabIndex = 0;
            this.rbYM2608P_Silent.Text = "Silent";
            this.rbYM2608P_Silent.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.cmbYM2608S_SCCI);
            this.groupBox6.Controls.Add(this.rbYM2608S_SCCI);
            this.groupBox6.Controls.Add(this.rbYM2608S_Silent);
            this.groupBox6.Controls.Add(this.rbYM2608S_Emu);
            this.groupBox6.Location = new System.Drawing.Point(3, 719);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(411, 38);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "YM2608(Secondary)";
            // 
            // cmbYM2608S_SCCI
            // 
            this.cmbYM2608S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2608S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2608S_SCCI.FormattingEnabled = true;
            this.cmbYM2608S_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2608S_SCCI.Name = "cmbYM2608S_SCCI";
            this.cmbYM2608S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2608S_SCCI.TabIndex = 2;
            // 
            // rbYM2608S_SCCI
            // 
            this.rbYM2608S_SCCI.AutoSize = true;
            this.rbYM2608S_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2608S_SCCI.Name = "rbYM2608S_SCCI";
            this.rbYM2608S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2608S_SCCI.TabIndex = 1;
            this.rbYM2608S_SCCI.Text = "Real";
            this.rbYM2608S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2608S_Silent
            // 
            this.rbYM2608S_Silent.AutoSize = true;
            this.rbYM2608S_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2608S_Silent.Name = "rbYM2608S_Silent";
            this.rbYM2608S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2608S_Silent.TabIndex = 0;
            this.rbYM2608S_Silent.Text = "Silent";
            this.rbYM2608S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2608S_Emu
            // 
            this.rbYM2608S_Emu.AutoSize = true;
            this.rbYM2608S_Emu.Checked = true;
            this.rbYM2608S_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2608S_Emu.Name = "rbYM2608S_Emu";
            this.rbYM2608S_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2608S_Emu.TabIndex = 0;
            this.rbYM2608S_Emu.TabStop = true;
            this.rbYM2608S_Emu.Text = "Emu";
            this.rbYM2608S_Emu.UseVisualStyleBackColor = true;
            // 
            // cmbYM2610BP_SCCI
            // 
            this.cmbYM2610BP_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2610BP_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2610BP_SCCI.FormattingEnabled = true;
            this.cmbYM2610BP_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2610BP_SCCI.Name = "cmbYM2610BP_SCCI";
            this.cmbYM2610BP_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2610BP_SCCI.TabIndex = 2;
            // 
            // rbYM2610BP_SCCI
            // 
            this.rbYM2610BP_SCCI.AutoSize = true;
            this.rbYM2610BP_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2610BP_SCCI.Name = "rbYM2610BP_SCCI";
            this.rbYM2610BP_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2610BP_SCCI.TabIndex = 1;
            this.rbYM2610BP_SCCI.Text = "Real";
            this.rbYM2610BP_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2610BP_Emu
            // 
            this.rbYM2610BP_Emu.AutoSize = true;
            this.rbYM2610BP_Emu.Checked = true;
            this.rbYM2610BP_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2610BP_Emu.Name = "rbYM2610BP_Emu";
            this.rbYM2610BP_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2610BP_Emu.TabIndex = 0;
            this.rbYM2610BP_Emu.TabStop = true;
            this.rbYM2610BP_Emu.Text = "Emu";
            this.rbYM2610BP_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.cmbSPPCMP_SCCI);
            this.groupBox7.Controls.Add(this.cmbYM2610BP_SCCI);
            this.groupBox7.Controls.Add(this.rbYM2610BP_SCCI);
            this.groupBox7.Controls.Add(this.rbYM2610BP_Silent);
            this.groupBox7.Controls.Add(this.rbYM2610BP_Emu);
            this.groupBox7.Location = new System.Drawing.Point(3, 808);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(411, 64);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "YM2610/B(Primary)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(173, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "+";
            // 
            // cmbSPPCMP_SCCI
            // 
            this.cmbSPPCMP_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSPPCMP_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSPPCMP_SCCI.FormattingEnabled = true;
            this.cmbSPPCMP_SCCI.Location = new System.Drawing.Point(190, 38);
            this.cmbSPPCMP_SCCI.Name = "cmbSPPCMP_SCCI";
            this.cmbSPPCMP_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbSPPCMP_SCCI.TabIndex = 2;
            // 
            // rbYM2610BP_Silent
            // 
            this.rbYM2610BP_Silent.AutoSize = true;
            this.rbYM2610BP_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2610BP_Silent.Name = "rbYM2610BP_Silent";
            this.rbYM2610BP_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2610BP_Silent.TabIndex = 0;
            this.rbYM2610BP_Silent.Text = "Silent";
            this.rbYM2610BP_Silent.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.cmbYM2610BS_SCCI);
            this.groupBox8.Controls.Add(this.rbYM2610BS_SCCI);
            this.groupBox8.Controls.Add(this.cmbSPPCMS_SCCI);
            this.groupBox8.Controls.Add(this.rbYM2610BS_Silent);
            this.groupBox8.Controls.Add(this.rbYM2610BS_Emu);
            this.groupBox8.Location = new System.Drawing.Point(3, 878);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(411, 64);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "YM2610/B(Secondary)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(173, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "+";
            // 
            // cmbYM2610BS_SCCI
            // 
            this.cmbYM2610BS_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2610BS_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2610BS_SCCI.FormattingEnabled = true;
            this.cmbYM2610BS_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2610BS_SCCI.Name = "cmbYM2610BS_SCCI";
            this.cmbYM2610BS_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2610BS_SCCI.TabIndex = 2;
            // 
            // rbYM2610BS_SCCI
            // 
            this.rbYM2610BS_SCCI.AutoSize = true;
            this.rbYM2610BS_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2610BS_SCCI.Name = "rbYM2610BS_SCCI";
            this.rbYM2610BS_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2610BS_SCCI.TabIndex = 1;
            this.rbYM2610BS_SCCI.Text = "Real";
            this.rbYM2610BS_SCCI.UseVisualStyleBackColor = true;
            // 
            // cmbSPPCMS_SCCI
            // 
            this.cmbSPPCMS_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSPPCMS_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSPPCMS_SCCI.FormattingEnabled = true;
            this.cmbSPPCMS_SCCI.Location = new System.Drawing.Point(190, 38);
            this.cmbSPPCMS_SCCI.Name = "cmbSPPCMS_SCCI";
            this.cmbSPPCMS_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbSPPCMS_SCCI.TabIndex = 2;
            // 
            // rbYM2610BS_Silent
            // 
            this.rbYM2610BS_Silent.AutoSize = true;
            this.rbYM2610BS_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2610BS_Silent.Name = "rbYM2610BS_Silent";
            this.rbYM2610BS_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2610BS_Silent.TabIndex = 0;
            this.rbYM2610BS_Silent.Text = "Silent";
            this.rbYM2610BS_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2610BS_Emu
            // 
            this.rbYM2610BS_Emu.AutoSize = true;
            this.rbYM2610BS_Emu.Checked = true;
            this.rbYM2610BS_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2610BS_Emu.Name = "rbYM2610BS_Emu";
            this.rbYM2610BS_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2610BS_Emu.TabIndex = 0;
            this.rbYM2610BS_Emu.TabStop = true;
            this.rbYM2610BS_Emu.Text = "Emu";
            this.rbYM2610BS_Emu.UseVisualStyleBackColor = true;
            // 
            // cbEmulationPCMOnly
            // 
            this.cbEmulationPCMOnly.AutoSize = true;
            this.cbEmulationPCMOnly.Location = new System.Drawing.Point(4, 18);
            this.cbEmulationPCMOnly.Name = "cbEmulationPCMOnly";
            this.cbEmulationPCMOnly.Size = new System.Drawing.Size(154, 16);
            this.cbEmulationPCMOnly.TabIndex = 5;
            this.cbEmulationPCMOnly.Text = "PCMだけエミュレーションする";
            this.cbEmulationPCMOnly.UseVisualStyleBackColor = true;
            // 
            // cbTwice
            // 
            this.cbTwice.AutoSize = true;
            this.cbTwice.Location = new System.Drawing.Point(206, 39);
            this.cbTwice.Name = "cbTwice";
            this.cbTwice.Size = new System.Drawing.Size(104, 16);
            this.cbTwice.TabIndex = 4;
            this.cbTwice.Text = "そのWait値を2倍";
            this.cbTwice.UseVisualStyleBackColor = true;
            // 
            // cbSendWait
            // 
            this.cbSendWait.AutoSize = true;
            this.cbSendWait.Location = new System.Drawing.Point(190, 18);
            this.cbSendWait.Name = "cbSendWait";
            this.cbSendWait.Size = new System.Drawing.Size(109, 16);
            this.cbSendWait.TabIndex = 3;
            this.cbSendWait.Text = "Waitシグナル発信";
            this.cbSendWait.UseVisualStyleBackColor = true;
            this.cbSendWait.CheckedChanged += new System.EventHandler(this.cbSendWait_CheckedChanged);
            // 
            // cmbYM2612P_SCCI
            // 
            this.cmbYM2612P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2612P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2612P_SCCI.FormattingEnabled = true;
            this.cmbYM2612P_SCCI.Location = new System.Drawing.Point(190, 36);
            this.cmbYM2612P_SCCI.Name = "cmbYM2612P_SCCI";
            this.cmbYM2612P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2612P_SCCI.TabIndex = 2;
            // 
            // rbYM2612P_SCCI
            // 
            this.rbYM2612P_SCCI.AutoSize = true;
            this.rbYM2612P_SCCI.Location = new System.Drawing.Point(138, 37);
            this.rbYM2612P_SCCI.Name = "rbYM2612P_SCCI";
            this.rbYM2612P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2612P_SCCI.TabIndex = 1;
            this.rbYM2612P_SCCI.Text = "Real";
            this.rbYM2612P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2612P_Emu
            // 
            this.rbYM2612P_Emu.AutoSize = true;
            this.rbYM2612P_Emu.Checked = true;
            this.rbYM2612P_Emu.Location = new System.Drawing.Point(234, 15);
            this.rbYM2612P_Emu.Name = "rbYM2612P_Emu";
            this.rbYM2612P_Emu.Size = new System.Drawing.Size(83, 16);
            this.rbYM2612P_Emu.TabIndex = 0;
            this.rbYM2612P_Emu.TabStop = true;
            this.rbYM2612P_Emu.Text = "Emu(mame)";
            this.rbYM2612P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.rbYM2612P_Silent);
            this.groupBox9.Controls.Add(this.cmbYM2612P_SCCI);
            this.groupBox9.Controls.Add(this.rbYM2612P_SCCI);
            this.groupBox9.Controls.Add(this.rbYM2612P_EmuNuked);
            this.groupBox9.Controls.Add(this.rbYM2612P_Emu);
            this.groupBox9.Location = new System.Drawing.Point(3, 993);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(411, 60);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "YM2612(Primary)";
            // 
            // rbYM2612P_Silent
            // 
            this.rbYM2612P_Silent.AutoSize = true;
            this.rbYM2612P_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbYM2612P_Silent.Name = "rbYM2612P_Silent";
            this.rbYM2612P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2612P_Silent.TabIndex = 0;
            this.rbYM2612P_Silent.Text = "Silent";
            this.rbYM2612P_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2612P_EmuNuked
            // 
            this.rbYM2612P_EmuNuked.AutoSize = true;
            this.rbYM2612P_EmuNuked.Location = new System.Drawing.Point(62, 15);
            this.rbYM2612P_EmuNuked.Name = "rbYM2612P_EmuNuked";
            this.rbYM2612P_EmuNuked.Size = new System.Drawing.Size(120, 16);
            this.rbYM2612P_EmuNuked.TabIndex = 0;
            this.rbYM2612P_EmuNuked.Text = "Emu(Nuked-OPN2)";
            this.rbYM2612P_EmuNuked.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.rbYM2612S_Silent);
            this.groupBox10.Controls.Add(this.cmbYM2612S_SCCI);
            this.groupBox10.Controls.Add(this.rbYM2612S_SCCI);
            this.groupBox10.Controls.Add(this.rbYM2612S_EmuNuked);
            this.groupBox10.Controls.Add(this.rbYM2612S_Emu);
            this.groupBox10.Location = new System.Drawing.Point(3, 1059);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(411, 60);
            this.groupBox10.TabIndex = 4;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "YM2612(Secondary)";
            // 
            // rbYM2612S_Silent
            // 
            this.rbYM2612S_Silent.AutoSize = true;
            this.rbYM2612S_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbYM2612S_Silent.Name = "rbYM2612S_Silent";
            this.rbYM2612S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2612S_Silent.TabIndex = 0;
            this.rbYM2612S_Silent.Text = "Silent";
            this.rbYM2612S_Silent.UseVisualStyleBackColor = true;
            // 
            // cmbYM2612S_SCCI
            // 
            this.cmbYM2612S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2612S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2612S_SCCI.FormattingEnabled = true;
            this.cmbYM2612S_SCCI.Location = new System.Drawing.Point(190, 36);
            this.cmbYM2612S_SCCI.Name = "cmbYM2612S_SCCI";
            this.cmbYM2612S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2612S_SCCI.TabIndex = 2;
            // 
            // rbYM2612S_SCCI
            // 
            this.rbYM2612S_SCCI.AutoSize = true;
            this.rbYM2612S_SCCI.Location = new System.Drawing.Point(138, 36);
            this.rbYM2612S_SCCI.Name = "rbYM2612S_SCCI";
            this.rbYM2612S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2612S_SCCI.TabIndex = 1;
            this.rbYM2612S_SCCI.Text = "Real";
            this.rbYM2612S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2612S_EmuNuked
            // 
            this.rbYM2612S_EmuNuked.AutoSize = true;
            this.rbYM2612S_EmuNuked.Location = new System.Drawing.Point(62, 15);
            this.rbYM2612S_EmuNuked.Name = "rbYM2612S_EmuNuked";
            this.rbYM2612S_EmuNuked.Size = new System.Drawing.Size(120, 16);
            this.rbYM2612S_EmuNuked.TabIndex = 0;
            this.rbYM2612S_EmuNuked.Text = "Emu(Nuked-OPN2)";
            this.rbYM2612S_EmuNuked.UseVisualStyleBackColor = true;
            // 
            // rbYM2612S_Emu
            // 
            this.rbYM2612S_Emu.AutoSize = true;
            this.rbYM2612S_Emu.Checked = true;
            this.rbYM2612S_Emu.Location = new System.Drawing.Point(234, 15);
            this.rbYM2612S_Emu.Name = "rbYM2612S_Emu";
            this.rbYM2612S_Emu.Size = new System.Drawing.Size(83, 16);
            this.rbYM2612S_Emu.TabIndex = 0;
            this.rbYM2612S_Emu.TabStop = true;
            this.rbYM2612S_Emu.Text = "Emu(mame)";
            this.rbYM2612S_Emu.UseVisualStyleBackColor = true;
            // 
            // cmbSN76489P_SCCI
            // 
            this.cmbSN76489P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSN76489P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSN76489P_SCCI.FormattingEnabled = true;
            this.cmbSN76489P_SCCI.Location = new System.Drawing.Point(190, 14);
            this.cmbSN76489P_SCCI.Name = "cmbSN76489P_SCCI";
            this.cmbSN76489P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbSN76489P_SCCI.TabIndex = 2;
            // 
            // rbSN76489P_SCCI
            // 
            this.rbSN76489P_SCCI.AutoSize = true;
            this.rbSN76489P_SCCI.Location = new System.Drawing.Point(138, 15);
            this.rbSN76489P_SCCI.Name = "rbSN76489P_SCCI";
            this.rbSN76489P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbSN76489P_SCCI.TabIndex = 1;
            this.rbSN76489P_SCCI.Text = "Real";
            this.rbSN76489P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbSN76489P_Emu
            // 
            this.rbSN76489P_Emu.AutoSize = true;
            this.rbSN76489P_Emu.Checked = true;
            this.rbSN76489P_Emu.Location = new System.Drawing.Point(62, 15);
            this.rbSN76489P_Emu.Name = "rbSN76489P_Emu";
            this.rbSN76489P_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbSN76489P_Emu.TabIndex = 0;
            this.rbSN76489P_Emu.TabStop = true;
            this.rbSN76489P_Emu.Text = "Emu";
            this.rbSN76489P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.cmbSN76489P_SCCI);
            this.groupBox11.Controls.Add(this.rbSN76489P_SCCI);
            this.groupBox11.Controls.Add(this.rbSN76489P_Silent);
            this.groupBox11.Controls.Add(this.rbSN76489P_Emu);
            this.groupBox11.Location = new System.Drawing.Point(3, 275);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(411, 40);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "SN76489(Primary)";
            // 
            // rbSN76489P_Silent
            // 
            this.rbSN76489P_Silent.AutoSize = true;
            this.rbSN76489P_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbSN76489P_Silent.Name = "rbSN76489P_Silent";
            this.rbSN76489P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbSN76489P_Silent.TabIndex = 0;
            this.rbSN76489P_Silent.Text = "Silent";
            this.rbSN76489P_Silent.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox12.Controls.Add(this.cmbSN76489S_SCCI);
            this.groupBox12.Controls.Add(this.rbSN76489S_SCCI);
            this.groupBox12.Controls.Add(this.rbSN76489S_Silent);
            this.groupBox12.Controls.Add(this.rbSN76489S_Emu);
            this.groupBox12.Location = new System.Drawing.Point(3, 321);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(411, 40);
            this.groupBox12.TabIndex = 5;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "SN76489(Secondary)";
            // 
            // cmbSN76489S_SCCI
            // 
            this.cmbSN76489S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSN76489S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSN76489S_SCCI.FormattingEnabled = true;
            this.cmbSN76489S_SCCI.Location = new System.Drawing.Point(190, 14);
            this.cmbSN76489S_SCCI.Name = "cmbSN76489S_SCCI";
            this.cmbSN76489S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbSN76489S_SCCI.TabIndex = 2;
            // 
            // rbSN76489S_SCCI
            // 
            this.rbSN76489S_SCCI.AutoSize = true;
            this.rbSN76489S_SCCI.Location = new System.Drawing.Point(138, 15);
            this.rbSN76489S_SCCI.Name = "rbSN76489S_SCCI";
            this.rbSN76489S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbSN76489S_SCCI.TabIndex = 1;
            this.rbSN76489S_SCCI.Text = "Real";
            this.rbSN76489S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbSN76489S_Silent
            // 
            this.rbSN76489S_Silent.AutoSize = true;
            this.rbSN76489S_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbSN76489S_Silent.Name = "rbSN76489S_Silent";
            this.rbSN76489S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbSN76489S_Silent.TabIndex = 0;
            this.rbSN76489S_Silent.Text = "Silent";
            this.rbSN76489S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbSN76489S_Emu
            // 
            this.rbSN76489S_Emu.AutoSize = true;
            this.rbSN76489S_Emu.Checked = true;
            this.rbSN76489S_Emu.Location = new System.Drawing.Point(62, 15);
            this.rbSN76489S_Emu.Name = "rbSN76489S_Emu";
            this.rbSN76489S_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbSN76489S_Emu.TabIndex = 0;
            this.rbSN76489S_Emu.TabStop = true;
            this.rbSN76489S_Emu.Text = "Emu";
            this.rbSN76489S_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox13.Controls.Add(this.cbSendWait);
            this.groupBox13.Controls.Add(this.cbEmulationPCMOnly);
            this.groupBox13.Controls.Add(this.cbTwice);
            this.groupBox13.Location = new System.Drawing.Point(3, 1125);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(411, 59);
            this.groupBox13.TabIndex = 6;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "YM2612(Use Real module Only!)";
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox14.Controls.Add(this.cmbC140S_SCCI);
            this.groupBox14.Controls.Add(this.rbC140S_SCCI);
            this.groupBox14.Controls.Add(this.rbC140S_Silent);
            this.groupBox14.Controls.Add(this.rbC140S_Emu);
            this.groupBox14.Location = new System.Drawing.Point(3, 137);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(411, 40);
            this.groupBox14.TabIndex = 6;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "C140(Secondary)";
            // 
            // cmbC140S_SCCI
            // 
            this.cmbC140S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbC140S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbC140S_SCCI.FormattingEnabled = true;
            this.cmbC140S_SCCI.Location = new System.Drawing.Point(190, 14);
            this.cmbC140S_SCCI.Name = "cmbC140S_SCCI";
            this.cmbC140S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbC140S_SCCI.TabIndex = 2;
            // 
            // rbC140S_SCCI
            // 
            this.rbC140S_SCCI.AutoSize = true;
            this.rbC140S_SCCI.Location = new System.Drawing.Point(138, 15);
            this.rbC140S_SCCI.Name = "rbC140S_SCCI";
            this.rbC140S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbC140S_SCCI.TabIndex = 1;
            this.rbC140S_SCCI.Text = "Real";
            this.rbC140S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbC140S_Silent
            // 
            this.rbC140S_Silent.AutoSize = true;
            this.rbC140S_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbC140S_Silent.Name = "rbC140S_Silent";
            this.rbC140S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbC140S_Silent.TabIndex = 0;
            this.rbC140S_Silent.Text = "Silent";
            this.rbC140S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbC140S_Emu
            // 
            this.rbC140S_Emu.AutoSize = true;
            this.rbC140S_Emu.Checked = true;
            this.rbC140S_Emu.Location = new System.Drawing.Point(62, 15);
            this.rbC140S_Emu.Name = "rbC140S_Emu";
            this.rbC140S_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbC140S_Emu.TabIndex = 0;
            this.rbC140S_Emu.TabStop = true;
            this.rbC140S_Emu.Text = "Emu";
            this.rbC140S_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox15.Controls.Add(this.cmbC140P_SCCI);
            this.groupBox15.Controls.Add(this.rbC140P_SCCI);
            this.groupBox15.Controls.Add(this.rbC140P_Silent);
            this.groupBox15.Controls.Add(this.rbC140P_Emu);
            this.groupBox15.Location = new System.Drawing.Point(3, 91);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(411, 40);
            this.groupBox15.TabIndex = 7;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "C140(Primary)";
            // 
            // cmbC140P_SCCI
            // 
            this.cmbC140P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbC140P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbC140P_SCCI.FormattingEnabled = true;
            this.cmbC140P_SCCI.Location = new System.Drawing.Point(190, 14);
            this.cmbC140P_SCCI.Name = "cmbC140P_SCCI";
            this.cmbC140P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbC140P_SCCI.TabIndex = 2;
            // 
            // rbC140P_SCCI
            // 
            this.rbC140P_SCCI.AutoSize = true;
            this.rbC140P_SCCI.Location = new System.Drawing.Point(138, 15);
            this.rbC140P_SCCI.Name = "rbC140P_SCCI";
            this.rbC140P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbC140P_SCCI.TabIndex = 1;
            this.rbC140P_SCCI.Text = "Real";
            this.rbC140P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbC140P_Silent
            // 
            this.rbC140P_Silent.AutoSize = true;
            this.rbC140P_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbC140P_Silent.Name = "rbC140P_Silent";
            this.rbC140P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbC140P_Silent.TabIndex = 0;
            this.rbC140P_Silent.Text = "Silent";
            this.rbC140P_Silent.UseVisualStyleBackColor = true;
            // 
            // rbC140P_Emu
            // 
            this.rbC140P_Emu.AutoSize = true;
            this.rbC140P_Emu.Checked = true;
            this.rbC140P_Emu.Location = new System.Drawing.Point(62, 15);
            this.rbC140P_Emu.Name = "rbC140P_Emu";
            this.rbC140P_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbC140P_Emu.TabIndex = 0;
            this.rbC140P_Emu.TabStop = true;
            this.rbC140P_Emu.Text = "Emu";
            this.rbC140P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox16.Controls.Add(this.cmbSEGAPCMS_SCCI);
            this.groupBox16.Controls.Add(this.rbSEGAPCMS_SCCI);
            this.groupBox16.Controls.Add(this.rbSEGAPCMS_Silent);
            this.groupBox16.Controls.Add(this.rbSEGAPCMS_Emu);
            this.groupBox16.Location = new System.Drawing.Point(3, 229);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(411, 40);
            this.groupBox16.TabIndex = 8;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "SEGAPCM(Secondary)";
            // 
            // cmbSEGAPCMS_SCCI
            // 
            this.cmbSEGAPCMS_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSEGAPCMS_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSEGAPCMS_SCCI.FormattingEnabled = true;
            this.cmbSEGAPCMS_SCCI.Location = new System.Drawing.Point(190, 14);
            this.cmbSEGAPCMS_SCCI.Name = "cmbSEGAPCMS_SCCI";
            this.cmbSEGAPCMS_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbSEGAPCMS_SCCI.TabIndex = 2;
            // 
            // rbSEGAPCMS_SCCI
            // 
            this.rbSEGAPCMS_SCCI.AutoSize = true;
            this.rbSEGAPCMS_SCCI.Location = new System.Drawing.Point(138, 15);
            this.rbSEGAPCMS_SCCI.Name = "rbSEGAPCMS_SCCI";
            this.rbSEGAPCMS_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbSEGAPCMS_SCCI.TabIndex = 1;
            this.rbSEGAPCMS_SCCI.Text = "Real";
            this.rbSEGAPCMS_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbSEGAPCMS_Silent
            // 
            this.rbSEGAPCMS_Silent.AutoSize = true;
            this.rbSEGAPCMS_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbSEGAPCMS_Silent.Name = "rbSEGAPCMS_Silent";
            this.rbSEGAPCMS_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbSEGAPCMS_Silent.TabIndex = 0;
            this.rbSEGAPCMS_Silent.Text = "Silent";
            this.rbSEGAPCMS_Silent.UseVisualStyleBackColor = true;
            // 
            // rbSEGAPCMS_Emu
            // 
            this.rbSEGAPCMS_Emu.AutoSize = true;
            this.rbSEGAPCMS_Emu.Checked = true;
            this.rbSEGAPCMS_Emu.Location = new System.Drawing.Point(62, 15);
            this.rbSEGAPCMS_Emu.Name = "rbSEGAPCMS_Emu";
            this.rbSEGAPCMS_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbSEGAPCMS_Emu.TabIndex = 0;
            this.rbSEGAPCMS_Emu.TabStop = true;
            this.rbSEGAPCMS_Emu.Text = "Emu";
            this.rbSEGAPCMS_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox17.Controls.Add(this.cmbSEGAPCMP_SCCI);
            this.groupBox17.Controls.Add(this.rbSEGAPCMP_SCCI);
            this.groupBox17.Controls.Add(this.rbSEGAPCMP_Silent);
            this.groupBox17.Controls.Add(this.rbSEGAPCMP_Emu);
            this.groupBox17.Location = new System.Drawing.Point(3, 183);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(411, 40);
            this.groupBox17.TabIndex = 9;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "SEGAPCM(Primary)";
            // 
            // cmbSEGAPCMP_SCCI
            // 
            this.cmbSEGAPCMP_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSEGAPCMP_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSEGAPCMP_SCCI.FormattingEnabled = true;
            this.cmbSEGAPCMP_SCCI.Location = new System.Drawing.Point(190, 14);
            this.cmbSEGAPCMP_SCCI.Name = "cmbSEGAPCMP_SCCI";
            this.cmbSEGAPCMP_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbSEGAPCMP_SCCI.TabIndex = 2;
            // 
            // rbSEGAPCMP_SCCI
            // 
            this.rbSEGAPCMP_SCCI.AutoSize = true;
            this.rbSEGAPCMP_SCCI.Location = new System.Drawing.Point(138, 15);
            this.rbSEGAPCMP_SCCI.Name = "rbSEGAPCMP_SCCI";
            this.rbSEGAPCMP_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbSEGAPCMP_SCCI.TabIndex = 1;
            this.rbSEGAPCMP_SCCI.Text = "Real";
            this.rbSEGAPCMP_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbSEGAPCMP_Silent
            // 
            this.rbSEGAPCMP_Silent.AutoSize = true;
            this.rbSEGAPCMP_Silent.Location = new System.Drawing.Point(4, 15);
            this.rbSEGAPCMP_Silent.Name = "rbSEGAPCMP_Silent";
            this.rbSEGAPCMP_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbSEGAPCMP_Silent.TabIndex = 0;
            this.rbSEGAPCMP_Silent.Text = "Silent";
            this.rbSEGAPCMP_Silent.UseVisualStyleBackColor = true;
            // 
            // rbSEGAPCMP_Emu
            // 
            this.rbSEGAPCMP_Emu.AutoSize = true;
            this.rbSEGAPCMP_Emu.Checked = true;
            this.rbSEGAPCMP_Emu.Location = new System.Drawing.Point(62, 15);
            this.rbSEGAPCMP_Emu.Name = "rbSEGAPCMP_Emu";
            this.rbSEGAPCMP_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbSEGAPCMP_Emu.TabIndex = 0;
            this.rbSEGAPCMP_Emu.TabStop = true;
            this.rbSEGAPCMP_Emu.Text = "Emu";
            this.rbSEGAPCMP_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox18.Controls.Add(this.cbEmulationOPNBADPCMOnly);
            this.groupBox18.Location = new System.Drawing.Point(3, 948);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(411, 39);
            this.groupBox18.TabIndex = 6;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "YM2610/B(Use Real module Only!)";
            // 
            // cbEmulationOPNBADPCMOnly
            // 
            this.cbEmulationOPNBADPCMOnly.AutoSize = true;
            this.cbEmulationOPNBADPCMOnly.Location = new System.Drawing.Point(4, 18);
            this.cbEmulationOPNBADPCMOnly.Name = "cbEmulationOPNBADPCMOnly";
            this.cbEmulationOPNBADPCMOnly.Size = new System.Drawing.Size(170, 16);
            this.cbEmulationOPNBADPCMOnly.TabIndex = 5;
            this.cbEmulationOPNBADPCMOnly.Text = "ADPCMだけエミュレーションする";
            this.cbEmulationOPNBADPCMOnly.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox19.Controls.Add(this.cbEmulationOPNAADPCMOnly);
            this.groupBox19.Location = new System.Drawing.Point(3, 763);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(411, 39);
            this.groupBox19.TabIndex = 6;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "YM2608(Use Real module Only!)";
            // 
            // cbEmulationOPNAADPCMOnly
            // 
            this.cbEmulationOPNAADPCMOnly.AutoSize = true;
            this.cbEmulationOPNAADPCMOnly.Location = new System.Drawing.Point(4, 18);
            this.cbEmulationOPNAADPCMOnly.Name = "cbEmulationOPNAADPCMOnly";
            this.cbEmulationOPNAADPCMOnly.Size = new System.Drawing.Size(170, 16);
            this.cbEmulationOPNAADPCMOnly.TabIndex = 5;
            this.cbEmulationOPNAADPCMOnly.Text = "ADPCMだけエミュレーションする";
            this.cbEmulationOPNAADPCMOnly.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox20.Controls.Add(this.cmbAY8910S_SCCI);
            this.groupBox20.Controls.Add(this.rbAY8910S_SCCI);
            this.groupBox20.Controls.Add(this.rbAY8910S_Silent);
            this.groupBox20.Controls.Add(this.rbAY8910S_Emu);
            this.groupBox20.Location = new System.Drawing.Point(3, 47);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(411, 38);
            this.groupBox20.TabIndex = 10;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "AY8910(Secondary)";
            // 
            // cmbAY8910S_SCCI
            // 
            this.cmbAY8910S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbAY8910S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAY8910S_SCCI.FormattingEnabled = true;
            this.cmbAY8910S_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbAY8910S_SCCI.Name = "cmbAY8910S_SCCI";
            this.cmbAY8910S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbAY8910S_SCCI.TabIndex = 2;
            // 
            // rbAY8910S_SCCI
            // 
            this.rbAY8910S_SCCI.AutoSize = true;
            this.rbAY8910S_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbAY8910S_SCCI.Name = "rbAY8910S_SCCI";
            this.rbAY8910S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbAY8910S_SCCI.TabIndex = 1;
            this.rbAY8910S_SCCI.Text = "Real";
            this.rbAY8910S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbAY8910S_Silent
            // 
            this.rbAY8910S_Silent.AutoSize = true;
            this.rbAY8910S_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbAY8910S_Silent.Name = "rbAY8910S_Silent";
            this.rbAY8910S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbAY8910S_Silent.TabIndex = 0;
            this.rbAY8910S_Silent.Text = "Silent";
            this.rbAY8910S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbAY8910S_Emu
            // 
            this.rbAY8910S_Emu.AutoSize = true;
            this.rbAY8910S_Emu.Checked = true;
            this.rbAY8910S_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbAY8910S_Emu.Name = "rbAY8910S_Emu";
            this.rbAY8910S_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbAY8910S_Emu.TabIndex = 0;
            this.rbAY8910S_Emu.TabStop = true;
            this.rbAY8910S_Emu.Text = "Emu";
            this.rbAY8910S_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox21.Controls.Add(this.cmbAY8910P_SCCI);
            this.groupBox21.Controls.Add(this.rbAY8910P_SCCI);
            this.groupBox21.Controls.Add(this.rbAY8910P_Silent);
            this.groupBox21.Controls.Add(this.rbAY8910P_Emu);
            this.groupBox21.Location = new System.Drawing.Point(3, 3);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(411, 38);
            this.groupBox21.TabIndex = 11;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "AY8910(Primary)";
            // 
            // cmbAY8910P_SCCI
            // 
            this.cmbAY8910P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbAY8910P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAY8910P_SCCI.FormattingEnabled = true;
            this.cmbAY8910P_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbAY8910P_SCCI.Name = "cmbAY8910P_SCCI";
            this.cmbAY8910P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbAY8910P_SCCI.TabIndex = 2;
            // 
            // rbAY8910P_SCCI
            // 
            this.rbAY8910P_SCCI.AutoSize = true;
            this.rbAY8910P_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbAY8910P_SCCI.Name = "rbAY8910P_SCCI";
            this.rbAY8910P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbAY8910P_SCCI.TabIndex = 1;
            this.rbAY8910P_SCCI.Text = "Real";
            this.rbAY8910P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbAY8910P_Silent
            // 
            this.rbAY8910P_Silent.AutoSize = true;
            this.rbAY8910P_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbAY8910P_Silent.Name = "rbAY8910P_Silent";
            this.rbAY8910P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbAY8910P_Silent.TabIndex = 0;
            this.rbAY8910P_Silent.Text = "Silent";
            this.rbAY8910P_Silent.UseVisualStyleBackColor = true;
            // 
            // rbAY8910P_Emu
            // 
            this.rbAY8910P_Emu.AutoSize = true;
            this.rbAY8910P_Emu.Checked = true;
            this.rbAY8910P_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbAY8910P_Emu.Name = "rbAY8910P_Emu";
            this.rbAY8910P_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbAY8910P_Emu.TabIndex = 0;
            this.rbAY8910P_Emu.TabStop = true;
            this.rbAY8910P_Emu.Text = "Emu";
            this.rbAY8910P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox22.Controls.Add(this.cmbYM2413P_SCCI);
            this.groupBox22.Controls.Add(this.rbYM2413P_SCCI);
            this.groupBox22.Controls.Add(this.rbYM2413P_Silent);
            this.groupBox22.Controls.Add(this.rbYM2413P_Emu);
            this.groupBox22.Location = new System.Drawing.Point(3, 587);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(411, 38);
            this.groupBox22.TabIndex = 1;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "YM2413(Primary)";
            // 
            // cmbYM2413P_SCCI
            // 
            this.cmbYM2413P_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2413P_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2413P_SCCI.FormattingEnabled = true;
            this.cmbYM2413P_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2413P_SCCI.Name = "cmbYM2413P_SCCI";
            this.cmbYM2413P_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2413P_SCCI.TabIndex = 2;
            // 
            // rbYM2413P_SCCI
            // 
            this.rbYM2413P_SCCI.AutoSize = true;
            this.rbYM2413P_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2413P_SCCI.Name = "rbYM2413P_SCCI";
            this.rbYM2413P_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2413P_SCCI.TabIndex = 1;
            this.rbYM2413P_SCCI.Text = "Real";
            this.rbYM2413P_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2413P_Silent
            // 
            this.rbYM2413P_Silent.AutoSize = true;
            this.rbYM2413P_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2413P_Silent.Name = "rbYM2413P_Silent";
            this.rbYM2413P_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2413P_Silent.TabIndex = 0;
            this.rbYM2413P_Silent.Text = "Silent";
            this.rbYM2413P_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2413P_Emu
            // 
            this.rbYM2413P_Emu.AutoSize = true;
            this.rbYM2413P_Emu.Checked = true;
            this.rbYM2413P_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2413P_Emu.Name = "rbYM2413P_Emu";
            this.rbYM2413P_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2413P_Emu.TabIndex = 0;
            this.rbYM2413P_Emu.TabStop = true;
            this.rbYM2413P_Emu.Text = "Emu";
            this.rbYM2413P_Emu.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox23.Controls.Add(this.cmbYM2413S_SCCI);
            this.groupBox23.Controls.Add(this.rbYM2413S_SCCI);
            this.groupBox23.Controls.Add(this.rbYM2413S_Silent);
            this.groupBox23.Controls.Add(this.rbYM2413S_Emu);
            this.groupBox23.Location = new System.Drawing.Point(3, 631);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(411, 38);
            this.groupBox23.TabIndex = 1;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "YM2413(Secondary)";
            // 
            // cmbYM2413S_SCCI
            // 
            this.cmbYM2413S_SCCI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbYM2413S_SCCI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYM2413S_SCCI.FormattingEnabled = true;
            this.cmbYM2413S_SCCI.Location = new System.Drawing.Point(190, 12);
            this.cmbYM2413S_SCCI.Name = "cmbYM2413S_SCCI";
            this.cmbYM2413S_SCCI.Size = new System.Drawing.Size(215, 20);
            this.cmbYM2413S_SCCI.TabIndex = 2;
            // 
            // rbYM2413S_SCCI
            // 
            this.rbYM2413S_SCCI.AutoSize = true;
            this.rbYM2413S_SCCI.Location = new System.Drawing.Point(138, 13);
            this.rbYM2413S_SCCI.Name = "rbYM2413S_SCCI";
            this.rbYM2413S_SCCI.Size = new System.Drawing.Size(46, 16);
            this.rbYM2413S_SCCI.TabIndex = 1;
            this.rbYM2413S_SCCI.Text = "Real";
            this.rbYM2413S_SCCI.UseVisualStyleBackColor = true;
            // 
            // rbYM2413S_Silent
            // 
            this.rbYM2413S_Silent.AutoSize = true;
            this.rbYM2413S_Silent.Location = new System.Drawing.Point(4, 13);
            this.rbYM2413S_Silent.Name = "rbYM2413S_Silent";
            this.rbYM2413S_Silent.Size = new System.Drawing.Size(52, 16);
            this.rbYM2413S_Silent.TabIndex = 0;
            this.rbYM2413S_Silent.Text = "Silent";
            this.rbYM2413S_Silent.UseVisualStyleBackColor = true;
            // 
            // rbYM2413S_Emu
            // 
            this.rbYM2413S_Emu.AutoSize = true;
            this.rbYM2413S_Emu.Checked = true;
            this.rbYM2413S_Emu.Location = new System.Drawing.Point(62, 13);
            this.rbYM2413S_Emu.Name = "rbYM2413S_Emu";
            this.rbYM2413S_Emu.Size = new System.Drawing.Size(45, 16);
            this.rbYM2413S_Emu.TabIndex = 0;
            this.rbYM2413S_Emu.TabStop = true;
            this.rbYM2413S_Emu.Text = "Emu";
            this.rbYM2413S_Emu.UseVisualStyleBackColor = true;
            // 
            // ucSettingInstruments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox20);
            this.Controls.Add(this.groupBox21);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox19);
            this.Controls.Add(this.groupBox18);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox23);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox22);
            this.Controls.Add(this.groupBox3);
            this.Name = "ucSettingInstruments";
            this.Size = new System.Drawing.Size(417, 1192);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        public System.Windows.Forms.ComboBox cmbYM2151P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2151P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2151P_Silent;
        public System.Windows.Forms.RadioButton rbYM2151P_Emu;
        public System.Windows.Forms.ComboBox cmbYM2151S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2151S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2151S_Silent;
        public System.Windows.Forms.RadioButton rbYM2151S_Emu;
        public System.Windows.Forms.ComboBox cmbYM2203P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2203P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2203P_Emu;
        public System.Windows.Forms.RadioButton rbYM2203P_Silent;
        public System.Windows.Forms.ComboBox cmbYM2203S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2203S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2203S_Silent;
        public System.Windows.Forms.RadioButton rbYM2203S_Emu;
        public System.Windows.Forms.ComboBox cmbYM2608P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2608P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2608P_Emu;
        public System.Windows.Forms.RadioButton rbYM2608P_Silent;
        public System.Windows.Forms.ComboBox cmbYM2608S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2608S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2608S_Silent;
        public System.Windows.Forms.RadioButton rbYM2608S_Emu;
        public System.Windows.Forms.ComboBox cmbYM2610BP_SCCI;
        public System.Windows.Forms.RadioButton rbYM2610BP_SCCI;
        public System.Windows.Forms.RadioButton rbYM2610BP_Emu;
        public System.Windows.Forms.RadioButton rbYM2610BP_Silent;
        public System.Windows.Forms.ComboBox cmbYM2610BS_SCCI;
        public System.Windows.Forms.RadioButton rbYM2610BS_SCCI;
        public System.Windows.Forms.RadioButton rbYM2610BS_Silent;
        public System.Windows.Forms.RadioButton rbYM2610BS_Emu;
        public System.Windows.Forms.CheckBox cbEmulationPCMOnly;
        public System.Windows.Forms.CheckBox cbTwice;
        public System.Windows.Forms.CheckBox cbSendWait;
        public System.Windows.Forms.ComboBox cmbYM2612P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2612P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2612P_Emu;
        public System.Windows.Forms.RadioButton rbYM2612P_Silent;
        public System.Windows.Forms.RadioButton rbYM2612S_Silent;
        public System.Windows.Forms.ComboBox cmbYM2612S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2612S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2612S_Emu;
        public System.Windows.Forms.ComboBox cmbSN76489P_SCCI;
        public System.Windows.Forms.RadioButton rbSN76489P_SCCI;
        public System.Windows.Forms.RadioButton rbSN76489P_Emu;
        public System.Windows.Forms.RadioButton rbSN76489P_Silent;
        public System.Windows.Forms.ComboBox cmbSN76489S_SCCI;
        public System.Windows.Forms.RadioButton rbSN76489S_SCCI;
        public System.Windows.Forms.RadioButton rbSN76489S_Silent;
        public System.Windows.Forms.RadioButton rbSN76489S_Emu;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        public System.Windows.Forms.ComboBox cmbC140S_SCCI;
        public System.Windows.Forms.RadioButton rbC140S_SCCI;
        public System.Windows.Forms.RadioButton rbC140S_Silent;
        public System.Windows.Forms.RadioButton rbC140S_Emu;
        private System.Windows.Forms.GroupBox groupBox15;
        public System.Windows.Forms.ComboBox cmbC140P_SCCI;
        public System.Windows.Forms.RadioButton rbC140P_SCCI;
        public System.Windows.Forms.RadioButton rbC140P_Silent;
        public System.Windows.Forms.RadioButton rbC140P_Emu;
        private System.Windows.Forms.GroupBox groupBox16;
        public System.Windows.Forms.ComboBox cmbSEGAPCMS_SCCI;
        public System.Windows.Forms.RadioButton rbSEGAPCMS_SCCI;
        public System.Windows.Forms.RadioButton rbSEGAPCMS_Silent;
        public System.Windows.Forms.RadioButton rbSEGAPCMS_Emu;
        private System.Windows.Forms.GroupBox groupBox17;
        public System.Windows.Forms.ComboBox cmbSEGAPCMP_SCCI;
        public System.Windows.Forms.RadioButton rbSEGAPCMP_SCCI;
        public System.Windows.Forms.RadioButton rbSEGAPCMP_Silent;
        public System.Windows.Forms.RadioButton rbSEGAPCMP_Emu;
        public System.Windows.Forms.ComboBox cmbSPPCMP_SCCI;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.ComboBox cmbSPPCMS_SCCI;
        public System.Windows.Forms.RadioButton rbYM2151P_EmuMame;
        public System.Windows.Forms.RadioButton rbYM2151S_EmuMame;
        public System.Windows.Forms.RadioButton rbYM2151P_EmuX68Sound;
        public System.Windows.Forms.RadioButton rbYM2151S_EmuX68Sound;
        public System.Windows.Forms.RadioButton rbYM2612P_EmuNuked;
        public System.Windows.Forms.RadioButton rbYM2612S_EmuNuked;
        private System.Windows.Forms.GroupBox groupBox18;
        public System.Windows.Forms.CheckBox cbEmulationOPNBADPCMOnly;
        private System.Windows.Forms.GroupBox groupBox19;
        public System.Windows.Forms.CheckBox cbEmulationOPNAADPCMOnly;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox20;
        public System.Windows.Forms.ComboBox cmbAY8910S_SCCI;
        public System.Windows.Forms.RadioButton rbAY8910S_SCCI;
        public System.Windows.Forms.RadioButton rbAY8910S_Silent;
        public System.Windows.Forms.RadioButton rbAY8910S_Emu;
        private System.Windows.Forms.GroupBox groupBox21;
        public System.Windows.Forms.ComboBox cmbAY8910P_SCCI;
        public System.Windows.Forms.RadioButton rbAY8910P_SCCI;
        public System.Windows.Forms.RadioButton rbAY8910P_Silent;
        public System.Windows.Forms.RadioButton rbAY8910P_Emu;
        private System.Windows.Forms.GroupBox groupBox22;
        public System.Windows.Forms.ComboBox cmbYM2413P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2413P_SCCI;
        public System.Windows.Forms.RadioButton rbYM2413P_Silent;
        public System.Windows.Forms.RadioButton rbYM2413P_Emu;
        private System.Windows.Forms.GroupBox groupBox23;
        public System.Windows.Forms.ComboBox cmbYM2413S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2413S_SCCI;
        public System.Windows.Forms.RadioButton rbYM2413S_Silent;
        public System.Windows.Forms.RadioButton rbYM2413S_Emu;
    }
}
