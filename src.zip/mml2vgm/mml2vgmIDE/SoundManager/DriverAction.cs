﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoundManager
{
    public class DriverAction
    {
        public Action Init;
        public Action Main;
        public Action Final;
    }
}
