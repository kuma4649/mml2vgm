﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Driver.libsidplayfp
{
    public class Const
    {
        public const string VERSION = "2.0.0beta";
        public const string PACKAGE_NAME = "libsidplayfp";
        public const string PACKAGE_VERSION="2.0.0beta";
        public const string PACKAGE_URL = "http://sourceforge.net/projects/sidplay-residfp/";
    }
}
