﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Driver.libsidplayfp.utils.MD5
{
    public class MD5_Defs
    {


//# include "sidendian.h"

//# ifdef WORDS_BIGENDIAN
//#define MD5_WORDS_BIG_ENDIAN
//#endif

        //this id dummy class.



    }
}
