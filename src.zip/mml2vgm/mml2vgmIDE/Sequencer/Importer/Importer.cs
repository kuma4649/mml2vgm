﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mml2vgmIDE.Sequencer.Importer
{
    public class Importer
    {
        public virtual string Convert(string fullPath)
        {
            return "";
        }
    }
}
