﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mml2vgmIDE
{
    public class VisVolume
    {
        public short master = 0;
        public short ym2151 = 0;
        public short ym2203 = 0;
        public short ym2203FM = 0;
        public short ym2203SSG = 0;
        public short ym2608 = 0;
        public short ym2608FM = 0;
        public short ym2608SSG = 0;
        public short ym2608Rtm = 0;
        public short ym2608APCM = 0;
        public short ym2610 = 0;
        public short ym2610FM = 0;
        public short ym2610SSG = 0;
        public short ym2610APCMA = 0;
        public short ym2610APCMB = 0;
        public short ym2612 = 0;

        public short ym2413 = 0;
        public short ym3526 = 0;
        public short y8950 = 0;
        public short ym3812 = 0;
        public short ymf262 = 0;
        public short ymf278b = 0;
        public short ymf271 = 0;
        public short ymz280b = 0;
        public short ay8910 = 0;
        public short sn76489 = 0;
        public short huc6280 = 0;

        public short rf5c164 = 0;
        public short rf5c68 = 0;
        public short pwm = 0;
        public short okim6258 = 0;
        public short okim6295 = 0;
        public short c140 = 0;
        public short c352 = 0;
        public short segaPCM = 0;
        public short multiPCM = 0;
        public short k051649 = 0;
        public short k053260 = 0;
        public short k054539 = 0;
        public short qSound = 0;
        public short ga20 = 0;

        public short APU = 0;
        public short DMC = 0;
        public short FDS = 0;
        public short MMC5 = 0;
        public short N160 = 0;
        public short VRC6 = 0;
        public short VRC7 = 0;
        public short FME7 = 0;
        public short DMG = 0;

    }
}
