﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mml2vgmIDE
{
    public class ChipLEDs
    {
        public byte PriOPN = 0;
        public byte PriOPN2 = 0;
        public byte PriOPNA = 0;
        public byte PriOPNB = 0;
        public byte PriOPL = 0;
        public byte PriY8950 = 0;
        public byte PriOPL2 = 0;
        public byte PriOPL3 = 0;
        public byte PriOPL4 = 0;
        public byte PriOPX = 0;
        public byte PriOPM = 0;
        public byte PriDCSG = 0;
        public byte PriRF5C = 0;
        public byte PriPWM = 0;
        public byte PriOKI5 = 0;
        public byte PriOKI9 = 0;
        public byte PriC140 = 0;
        public byte PriSPCM = 0;
        public byte PriAY10 = 0;
        public byte PriOPLL = 0;
        public byte PriHuC = 0;
        public byte PriQsnd = 0;
        public byte PriC352 = 0;
        public byte PriGA20 = 0;
        public byte PriK051649 = 0;
        public byte PriK053260 = 0;
        public byte PriK054539 = 0;
        public byte PriDMG = 0;
        public byte PriNES = 0;
        public byte PriDMC = 0;
        public byte PriFDS = 0;
        public byte PriFME7 = 0;
        public byte PriMMC5 = 0;
        public byte PriN160 = 0;
        public byte PriVRC6 = 0;
        public byte PriVRC7 = 0;
        public byte PriHuC8 = 0;
        public byte PriMPCM = 0;
        public byte PriYMZ = 0;
        public byte PriSID = 0;
        public byte PriMID = 0;

        public byte SecOPN = 0;
        public byte SecOPN2 = 0;
        public byte SecOPNA = 0;
        public byte SecOPNB = 0;
        public byte SecOPL = 0;
        public byte SecY8950 = 0;
        public byte SecOPL2 = 0;
        public byte SecOPL3 = 0;
        public byte SecOPL4 = 0;
        public byte SecOPX = 0;
        public byte SecOPM = 0;
        public byte SecDCSG = 0;
        public byte SecRF5C = 0;
        public byte SecPWM = 0;
        public byte SecOKI5 = 0;
        public byte SecOKI9 = 0;
        public byte SecC140 = 0;
        public byte SecSPCM = 0;
        public byte SecAY10 = 0;
        public byte SecOPLL = 0;
        public byte SecHuC = 0;
        public byte SecC352 = 0;
        public byte SecGA20 = 0;
        public byte SecK051649 = 0;
        public byte SecK053260 = 0;
        public byte SecK054539 = 0;
        public byte SecDMG = 0;
        public byte SecNES = 0;
        public byte SecDMC = 0;
        public byte SecFDS = 0;
        public byte SecFME7 = 0;
        public byte SecMMC5 = 0;
        public byte SecN160 = 0;
        public byte SecVRC6 = 0;
        public byte SecVRC7 = 0;
        public byte SecHuC8 = 0;
        public byte SecMPCM = 0;
        public byte SecYMZ = 0;
        public byte SecSID = 0;
        public byte SecMID = 0;

    }
}
